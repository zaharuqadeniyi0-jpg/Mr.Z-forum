# Portfolio — Adeniyi Zaharuq

This is a ready-to-deploy static portfolio website built from the content you provided.

## How to use

### Preview locally
1. Open `index.html` in a web browser (double-click). No server required.

### Deploy to GitHub Pages (quick)
1. Create a new GitHub repository (public or private).
2. Upload all files from this folder (`index.html`, `styles.css`, `README.md`).
3. In the repository settings -> Pages, set the branch to `main` (or `master`) and root `/`.
4. GitHub will publish a URL like `https://<username>.github.io/<repo>/` within a minute.

### Deploy to Vercel (recommended for automatic updates)
1. Create a Vercel account and connect your GitHub.
2. Import the repository and select the framework "Other" or "Static".
3. Deploy — Vercel will provide a public URL instantly.

### Deploy to Netlify
1. Create a Netlify account.
2. Drag & drop the folder into Netlify's dashboard or connect via Git.
3. Netlify will publish a public URL.

If you'd like, I can:
- Convert this to a React/Vite project (ready for Vercel).
- Create a GitHub repository for you (I'll provide instructions — you'll still need to sign in to GitHub).
