
async function fetchAIContent(prompt) {
    try {
        const response = await fetch('/.netlify/functions/fetchAI', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt })
        });
        const data = await response.json();
        return data.result;
    } catch (err) {
        console.error(err);
        return "Error fetching AI content";
    }
}

async function loadNews() {
    const container = document.getElementById('news-container');
    container.innerText = "Loading...";
    const newsContent = await fetchAIContent("Provide latest FC 25 Mobile news and leaks with sources.");
    container.innerHTML = newsContent.replace(/\n/g, "<br>");
}

async function loadTopPlayers() {
    const container = document.getElementById('players-container');
    container.innerText = "Loading...";
    const playersContent = await fetchAIContent("List top FC 25 Mobile players with full names and positions.");
    container.innerHTML = playersContent.replace(/\n/g, "<br>");
}

async function loadSquadBuilder() {
    const container = document.getElementById('squad-container');
    container.innerText = "Loading...";
    const squadContent = await fetchAIContent("Suggest an optimal FC 25 Mobile squad including player names.");
    container.innerHTML = squadContent.replace(/\n/g, "<br>");
}

function calculateOVR() {
    const attack = Number(document.getElementById('attack').value);
    const defense = Number(document.getElementById('defense').value);
    const midfield = Number(document.getElementById('midfield').value);
    if (isNaN(attack) || isNaN(defense) || isNaN(midfield)) {
        alert("Please enter valid numbers");
        return;
    }
    const ovr = Math.round((attack + defense + midfield)/3);
    document.getElementById('ovr-result').innerText = `Calculated OVR: ${ovr}`;
}

async function chatAI() {
    const userInput = document.getElementById('user-input').value;
    const container = document.getElementById('chat-response');
    container.innerText = "Thinking...";
    const aiResponse = await fetchAIContent("Answer this FC 25 Mobile question: " + userInput);
    container.innerHTML = aiResponse.replace(/\n/g, "<br>");
}

window.onload = () => {
    loadNews();
    loadTopPlayers();
    loadSquadBuilder();
}
        